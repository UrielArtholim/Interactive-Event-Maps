﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interactive_Event_Maps.Models
{
	public class Position(double x, double y)
	{
		public double X { get; set; } = x;
		public double Y { get; set; } = y;

	}
}
