﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Interactive_Event_Maps.Models
{
	public class RepoEvent
	{
		[JsonConstructor]
		public RepoEvent() { }

		public RepoEvent(string? name, string? path, string? sha, string? size, string? url, string? html_url, string? git_url,
			string? download_url, string? type, string? self, string? git, string? html)
		{ 
			this.Name = name ?? String.Empty;
			this.Path = path ?? String.Empty;
			this.Sha = sha ?? String.Empty;
			this.Size = size ?? String.Empty;
			this.Url = url ?? String.Empty;
			this.Html_url = html_url ?? String.Empty;
			this.Git_url = git_url ?? String.Empty;
			this.Download_url = download_url ?? String.Empty;
			this.Type = type ?? String.Empty;
			this._Links = new Links(self ?? String.Empty, git ?? String.Empty, html ?? String.Empty);
		}
		[JsonInclude]
		public string? Name { get; set; }
		[JsonInclude] 
		public string? Path { get; set; }
		[JsonInclude] 
		public string? Sha { get; set; }
		[JsonInclude] 
		public string? Size { get; set; }
		[JsonInclude]
		public string? Url { get; set; }
		[JsonInclude] 
		public string? Html_url { get; set; }
		[JsonInclude] 
		public string? Git_url { get; set; }
		[JsonInclude] 
		public string? Download_url { get; set; }
		[JsonInclude] 
		public string? Type { get; set; }
		[JsonInclude] 
		public Links? _Links { get; set; }
	}	
}
