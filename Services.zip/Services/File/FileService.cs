﻿namespace Interactive_Event_Maps.Services.File
{
	public partial class FileService : IFileService
	{
		private readonly string _baseFolder = FileSystem.Current.AppDataDirectory;

		public FileService()
		{

		}

		public async Task<bool> UpdateEventFilesAsync(byte[] data)
		{
			bool isModified = false;
			bool fileSaved = await this.ToFileAsync(data);
			return isModified;
		}
	}
}
