﻿namespace Interactive_Event_Maps.Services.File
{
	public interface IFileService
	{
		public Task<bool> UpdateEventFilesAsync(byte[] data);
	}
}
