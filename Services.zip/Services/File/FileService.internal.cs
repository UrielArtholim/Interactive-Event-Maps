﻿using System.Diagnostics;

namespace Interactive_Event_Maps.Services.File
{
	public partial class FileService
	{
		internal async Task<bool> ToFileAsync(byte[] data)
		{
			string tempFilePath = Path.Combine(this._baseFolder, "temp", "repoData.zip");
			await System.IO.File.WriteAllBytesAsync(tempFilePath.ToString(), data);
			Debug.Assert(tempFilePath != null);
			Console.WriteLine(tempFilePath.ToString());
			return Directory.Exists(tempFilePath);
		}

		/*internal async Task GetEventFiles(string eventName, string tempFile)
		{

		}*/
	}
}
