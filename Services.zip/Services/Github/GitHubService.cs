﻿using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace Interactive_Event_Maps.Services.Github
{
	public partial class GitHubService: IGitHubService
	{
		private string? _token;
		private HttpClient _httpClient;
		private JsonSerializerOptions _jsonSerializerOptions;

		public GitHubService() 
		{
			Task.Run(SetTokenAsync);
			Token = Task.Run(GetTokenAsync).GetAwaiter().GetResult();
			_httpClient = new HttpClient();
			_jsonSerializerOptions = new JsonSerializerOptions
			{
				PropertyNameCaseInsensitive = true,
				WriteIndented = true,
			};
		}

		public string? Token { get => _token; set => _token = value; }
		public string? GetToken() { return _token; }

		public async Task<string?> SendTextAPIRequestAsync(Dictionary<string,string> headers, string endpoint, string? body = null, bool isNewItem = false)
		{
			string? data = default;
			Uri uri = new(endpoint);
			try
			{
				HttpRequestMessage? request = null;
				HttpResponseMessage? response = null;
				if(body == null)
				{
					request = new HttpRequestMessage(HttpMethod.Get, uri);
					foreach(KeyValuePair<string,string> kvp in headers)
					{
						request.Headers.Add(kvp.Key, kvp.Value);
					}
					response = await _httpClient.SendAsync(request);
					if (response.IsSuccessStatusCode)
					{
						Debug.WriteLine(@"\tRequest sent successfully");
						data = await response.Content.ReadAsStringAsync();
					}
				}
				else
				{
					StringContent bodyContent = new StringContent(JsonSerializer.Serialize(body, _jsonSerializerOptions),Encoding.UTF8, "application/json");
					if(isNewItem)
					{
						request = new HttpRequestMessage(HttpMethod.Post, uri);
						foreach (KeyValuePair<string, string> kvp in headers)
						{
							request.Headers.Add(kvp.Key, kvp.Value);
						}
						response = await _httpClient.SendAsync(request);
					}else
					{
						request = new HttpRequestMessage(HttpMethod.Put, uri);
						foreach (KeyValuePair<string, string> kvp in headers)
						{
							request.Headers.Add(kvp.Key, kvp.Value);
						}
						response = await _httpClient.PostAsync(endpoint, bodyContent);
					}
					if(response.IsSuccessStatusCode)
					{
						Debug.WriteLine(@"\tRequest sent successfully");
						data = await response.Content.ReadAsStringAsync();
					}
				}				
			}
			catch (Exception ex)
			{
				Debug.WriteLine(@"\tERROR {0}", ex.Message);
			}
			return data;
		}

		public async Task<byte[]?> SendFileAPIRequestAsync(Dictionary<string, string> headers, string endpoint, string? body = null, bool isNewItem = false)
		{
			byte[]? data = default;
			Uri uri = new(endpoint);
			try
			{
				HttpRequestMessage? request = null;
				HttpResponseMessage? response = null;
				if (body == null)
				{
					request = new HttpRequestMessage(HttpMethod.Get, uri);
					foreach (KeyValuePair<string, string> kvp in headers)
					{
						request.Headers.Add(kvp.Key, kvp.Value);
					}
					response = await _httpClient.SendAsync(request);
					if (response.IsSuccessStatusCode)
					{
						Debug.WriteLine(@"\tRequest sent successfully");
						data = await response.Content.ReadAsByteArrayAsync();
					}
				}
				else
				{
					StringContent bodyContent = new StringContent(JsonSerializer.Serialize(body, _jsonSerializerOptions), Encoding.UTF8, "application/json");
					if (isNewItem)
					{
						request = new HttpRequestMessage(HttpMethod.Post, uri);
						foreach (KeyValuePair<string, string> kvp in headers)
						{
							request.Headers.Add(kvp.Key, kvp.Value);
						}
						response = await _httpClient.SendAsync(request);
					}
					else
					{
						request = new HttpRequestMessage(HttpMethod.Put, uri);
						foreach (KeyValuePair<string, string> kvp in headers)
						{
							request.Headers.Add(kvp.Key, kvp.Value);
						}
						response = await _httpClient.PostAsync(endpoint, bodyContent);
					}
					if (response.IsSuccessStatusCode)
					{
						Debug.WriteLine(@"\tRequest sent successfully");
						data = await response.Content.ReadAsByteArrayAsync();
					}
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine(@"\tERROR {0}", ex.Message);
			}
			return data;
		}


	}
}
