﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interactive_Event_Maps.Services.Github
{
	public interface IGitHubService
	{
		public Task<string?> SendTextAPIRequestAsync(Dictionary<string,string> headers, string endpoint, string? body, bool isNewItem);
		public Task<byte[]?> SendFileAPIRequestAsync(Dictionary<string, string> headers, string endpoint, string? body, bool isNewItem);

		public string? GetToken();

	}
}
