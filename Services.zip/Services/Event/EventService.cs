﻿using Interactive_Event_Maps.Services.File;
using Interactive_Event_Maps.Services.Github;
using System.Text.Json;

namespace Interactive_Event_Maps.Services.Event
{
	public partial class EventService : IEventService
	{
		private readonly IGitHubService gitHubService;
		private readonly IFileService fileService;
		private string _token;
		private Dictionary<string, string> headers;
		

		public EventService(IGitHubService gitHubService, IFileService fileService)
		{
			this.gitHubService = gitHubService;
			this.fileService = fileService;
			this._token = this.gitHubService.GetToken() ?? throw new Exception("Token not found");
			this.headers = new Dictionary<string, string>();
			headers.Add("Accept", "application/json");
			headers.Add("Authorization", _token);
			headers.Add("X-GitHub-Api-Version", "2022-11-28");
		}

		public async Task<List<string>> GetAvailableEventsAsync()
		{
			List<string> events = [];
			string endpoint = baseUri + "contents/Maps";
			string? data = await this.gitHubService.SendTextAPIRequestAsync(headers, endpoint, null, false);
			if(data != null)
			{
				events = GetEventsFromJson(data);
			}			
			return events;
		}

		public async Task UpdateLocalEventsAsync()
		{
			string endpoint = baseUri + "zipball/main";
			byte[]? repoData = await this.gitHubService.SendFileAPIRequestAsync(headers, endpoint, null, false);
			bool updated = await this.fileService.UpdateEventFilesAsync(repoData);
		}

		
	}
}
