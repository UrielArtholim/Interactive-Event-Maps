﻿namespace Interactive_Event_Maps.Services.Event
{
	public interface IEventService
	{
		Task<List<string>> GetAvailableEventsAsync();

		Task UpdateLocalEventsAsync();
	}
}
